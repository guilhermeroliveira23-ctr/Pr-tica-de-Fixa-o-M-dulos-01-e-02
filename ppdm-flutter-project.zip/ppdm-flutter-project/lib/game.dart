/// Lógica do jogo e tipos de apoio para o Birdle,
/// um jogo de adivinhação de palavras de cinco letras
/// (baseado no tutorial oficial de Flutter).
library;

import 'dart:collection';
import 'dart:math';

/// Resultado da avaliação de uma [Letter] de uma tentativa
/// contra a palavra oculta.
enum HitType {
  /// A letra ainda não foi avaliada.
  none,

  /// A letra corresponde à letra da palavra oculta na mesma posição.
  hit,

  /// A letra existe na palavra oculta, mas em outra posição.
  partial,

  /// A letra não existe na palavra oculta.
  miss,
}

/// Um caractere associado ao seu [HitType] em relação à palavra oculta.
typedef Letter = ({String char, HitType type});

/// Todas as palavras que podem ser digitadas como tentativa válida.
const List<String> allLegalGuesses = [...legalWords, ...legalGuesses];

/// Palavras que podem ser escolhidas como a palavra oculta.
const List<String> legalWords = ['aback', 'abase', 'abate', 'abbey', 'abbot'];

/// Palavras adicionais aceitas como tentativa, além de [legalWords].
const List<String> legalGuesses = [
  'aback',
  'abase',
  'abate',
  'abbey',
  'abbot',
  'abhor',
  'abide',
  'abled',
  'abode',
  'abort',
];

/// Estado de uma partida do Birdle.
///
/// Expõe o estado e os métodos que a UI precisa para
/// avaliar tentativas e acompanhar o progresso,
/// mas não avança o jogo sozinho.
///
/// A UI conduz cada rodada chamando [guess] para enviar uma tentativa e
/// [resetGame] para recomeçar.
class Game {
  /// Número máximo padrão de tentativas permitidas em um [Game].
  static const int defaultMaxGuesses = 5;

  /// Cria uma nova partida com [maxGuesses] tentativas permitidas.
  ///
  /// Se [seed] for informado, a palavra oculta é escolhida
  /// deterministicamente a partir de [legalWords];
  /// caso contrário, é escolhida aleatoriamente.
  Game({this.maxGuesses = defaultMaxGuesses, this.seed})
    : _wordToGuess = _generateInitialWord(seed),
      _guesses = List<Word>.filled(maxGuesses, Word.empty());

  /// Número máximo de tentativas permitidas nesta partida.
  final int maxGuesses;

  /// Seed usada para escolher a palavra oculta,
  /// ou `null` se ela foi escolhida aleatoriamente.
  final int? seed;

  /// A palavra oculta atual, exposta publicamente por [hiddenWord].
  Word _wordToGuess;

  /// Armazenamento interno de [guesses].
  List<Word> _guesses;

  /// A palavra que o jogador está tentando adivinhar.
  Word get hiddenWord => _wordToGuess;

  /// Uma visão não modificável de cada tentativa, incluindo as vazias.
  UnmodifiableListView<Word> get guesses => UnmodifiableListView(_guesses);

  /// A tentativa mais recente enviada,
  /// ou uma [Word] vazia se nenhuma tentativa foi feita.
  Word get previousGuess {
    final index = _guesses.lastIndexWhere((word) => word.isNotEmpty);
    return index == -1 ? Word.empty() : _guesses[index];
  }

  /// O índice do próximo slot de tentativa vazio, ou `-1` se todos estiverem cheios.
  int get activeIndex => _guesses.indexWhere((word) => word.isEmpty);

  /// O número de tentativas ainda disponíveis para o jogador.
  int get guessesRemaining {
    if (activeIndex == -1) return 0;
    return maxGuesses - activeIndex;
  }

  /// Se a última tentativa corresponde à palavra oculta.
  bool get didWin {
    if (_guesses.first.isEmpty) return false;

    for (final letter in previousGuess) {
      if (letter.type != HitType.hit) return false;
    }

    return true;
  }

  /// Se todas as tentativas permitidas foram usadas sem vitória.
  bool get didLose => guessesRemaining == 0 && !didWin;

  /// Escolhe uma nova palavra oculta e limpa todas as tentativas enviadas.
  void resetGame() {
    _wordToGuess = _generateInitialWord(seed);
    _guesses = List<Word>.filled(maxGuesses, Word.empty());
  }

  /// Avalia [guess] contra a palavra oculta, registra o resultado
  /// em [guesses] e o retorna.
  Word guess(String guess) {
    final result = matchGuessOnly(guess);
    addGuessToList(result);
    return result;
  }

  /// Se [guess] é uma palavra válida para tentativa.
  bool isLegalGuess(String guess) => Word.fromString(guess).isLegalGuess;

  /// Avalia [guess] contra a palavra oculta sem avançar o jogo.
  Word matchGuessOnly(String guess) =>
      Word.fromString(guess).evaluateGuess(_wordToGuess);

  /// Armazena [guess] no próximo slot vazio de [guesses].
  void addGuessToList(Word guess) {
    final guessIndex = activeIndex;
    if (guessIndex == -1) {
      throw StateError('Não há mais tentativas disponíveis.');
    }

    _guesses[guessIndex] = guess;
  }

  /// Retorna a palavra oculta inicial de uma nova rodada.
  static Word _generateInitialWord(int? seed) =>
      seed == null ? Word.random() : Word.fromSeed(seed);
}

/// Uma palavra de cinco letras composta por [Letter]s,
/// cada uma com seu [HitType].
class Word with IterableMixin<Letter> {
  /// Cria uma palavra a partir da lista de [Letter]s informada.
  Word(this._letters);

  /// Cria uma palavra com cinco letras em branco, do tipo [HitType.none].
  factory Word.empty() =>
      Word(List<Letter>.filled(5, (char: '', type: HitType.none)));

  /// Cria uma [Word] a partir de [guess].
  factory Word.fromString(String guess) {
    if (guess.length != 5) {
      throw ArgumentError.value(
        guess,
        'guess',
        'Deve ter exatamente 5 caracteres.',
      );
    }

    final letters = guess
        .toLowerCase()
        .split('')
        .map((char) => (char: char, type: HitType.none))
        .toList();
    return Word(letters);
  }

  /// Cria uma palavra escolhida aleatoriamente entre [legalWords].
  factory Word.random() {
    final random = Random();
    final nextWord = legalWords[random.nextInt(legalWords.length)];
    return Word.fromString(nextWord);
  }

  /// Cria uma palavra escolhida de [legalWords] usando [seed] como índice.
  factory Word.fromSeed(int seed) =>
      Word.fromString(legalWords[seed % legalWords.length]);

  /// Lista não modificável de [Letter]s que compõem esta palavra.
  final List<Letter> _letters;

  @override
  Iterator<Letter> get iterator => _letters.iterator;

  /// Se todas as [Letter]s desta palavra não têm caractere.
  @override
  bool get isEmpty => every((letter) => letter.char.isEmpty);

  @override
  int get length => _letters.length;

  /// A [Letter] no índice [i] da palavra.
  Letter operator [](int i) => _letters[i];

  @override
  String toString() => _letters.map((letter) => letter.char).join().trim();
}

/// Lógica de validação e avaliação de tentativas sobre [Word].
extension WordUtils on Word {
  /// Se esta palavra existe em [allLegalGuesses].
  bool get isLegalGuess => allLegalGuesses.contains(toString());

  /// Compara esta [Word] com a [hiddenWord] informada
  /// e retorna uma nova [Word] com as mesmas letras,
  /// mas com cada [Letter] tendo um novo [HitType].
  Word evaluateGuess(Word hiddenWord) {
    assert(isLegalGuess);

    final result = List<Letter>.filled(length, (char: '', type: HitType.none));
    final unmatchedHiddenLetterCounts = <String, int>{};

    for (var i = 0; i < length; i++) {
      final guessChar = this[i].char;
      final hiddenChar = hiddenWord[i].char;

      if (guessChar == hiddenChar) {
        result[i] = (char: guessChar, type: HitType.hit);
      } else {
        final unmatchedCount = unmatchedHiddenLetterCounts[hiddenChar] ?? 0;
        unmatchedHiddenLetterCounts[hiddenChar] = unmatchedCount + 1;
      }
    }

    for (var i = 0; i < length; i++) {
      if (result[i].type == HitType.hit) continue;

      final guessChar = this[i].char;
      final unmatchedCount = unmatchedHiddenLetterCounts[guessChar] ?? 0;
      final isPartial = unmatchedCount > 0;
      if (isPartial) {
        unmatchedHiddenLetterCounts[guessChar] = unmatchedCount - 1;
      }

      result[i] = (
        char: guessChar,
        type: isPartial ? HitType.partial : HitType.miss,
      );
    }

    return Word(result);
  }
}
