import 'package:flutter/material.dart';

import '../game.dart';
import '../widgets/game_board.dart';

/// Tela principal do jogo.
///
/// É um [StatefulWidget] porque precisa "lembrar" e atualizar,
/// ao longo do tempo, o estado da partida (tentativas já feitas,
/// tentativas restantes, texto digitado pelo usuário) sempre que o
/// usuário interage com a tela.
class GameScreen extends StatefulWidget {
  const GameScreen({super.key});

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  final Game _game = Game();
  final TextEditingController _controller = TextEditingController();

  void _submitGuess() {
    final guess = _controller.text.trim().toLowerCase();

    if (guess.length != 5) {
      _showMessage('A palavra precisa ter 5 letras.');
      return;
    }

    if (!_game.isLegalGuess(guess)) {
      _showMessage('Palavra não permitida. Tente outra.');
      return;
    }

    // setState() avisa o Flutter que o estado mudou: o método build()
    // será chamado novamente e a tela será redesenhada com a nova
    // tentativa registrada no tabuleiro.
    setState(() {
      _game.guess(guess);
      _controller.clear();
    });

    if (_game.didWin) {
      _showMessage('Parabéns! Você acertou a palavra 🎉');
    } else if (_game.didLose) {
      _showMessage('Fim de jogo! A palavra era "${_game.hiddenWord}".');
    }
  }

  void _resetGame() {
    setState(() {
      _game.resetGame();
      _controller.clear();
    });
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Birdle · PPDM'),
        actions: [
          IconButton(
            onPressed: _resetGame,
            icon: const Icon(Icons.refresh),
            tooltip: 'Reiniciar jogo',
          ),
        ],
      ),
      // SingleChildScrollView evita overflow em telas menores,
      // permitindo rolar o conteúdo quando necessário.
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Tentativas restantes: ${_game.guessesRemaining}',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(height: 16),
              GameBoard(guesses: _game.guesses, wordLength: 5),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      maxLength: 5,
                      textCapitalization: TextCapitalization.characters,
                      decoration: const InputDecoration(
                        labelText: 'Sua tentativa',
                        border: OutlineInputBorder(),
                        counterText: '',
                      ),
                      onSubmitted: (_) => _submitGuess(),
                    ),
                  ),
                  const SizedBox(width: 8),
                  ElevatedButton(
                    onPressed: _submitGuess,
                    child: const Text('Enviar'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
