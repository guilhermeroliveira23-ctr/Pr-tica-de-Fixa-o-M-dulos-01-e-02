import 'package:flutter/material.dart';

import '../game.dart';

/// Representa uma única letra na grade do jogo.
///
/// É um [StatelessWidget] porque a cor e o texto exibidos dependem
/// apenas dos parâmetros recebidos ([letter] e [hitType]) — o widget
/// não precisa lembrar de nada entre reconstruções, apenas exibir
/// o que foi passado a ele.
class Tile extends StatelessWidget {
  const Tile(this.letter, this.hitType, {super.key});

  /// A letra exibida no centro do quadrado.
  final String letter;

  /// O resultado da avaliação dessa letra (define a cor de fundo).
  final HitType hitType;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 56,
      height: 56,
      margin: const EdgeInsets.all(4),
      alignment: Alignment.center,
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade400),
        borderRadius: BorderRadius.circular(6),
        color: switch (hitType) {
          HitType.hit => Colors.green,
          HitType.partial => Colors.orange,
          HitType.miss => Colors.grey.shade500,
          HitType.none => Colors.white,
        },
      ),
      child: Text(
        letter.toUpperCase(),
        style: Theme.of(context).textTheme.titleLarge?.copyWith(
              color: hitType == HitType.none ? Colors.black87 : Colors.white,
              fontWeight: FontWeight.bold,
            ),
      ),
    );
  }
}
