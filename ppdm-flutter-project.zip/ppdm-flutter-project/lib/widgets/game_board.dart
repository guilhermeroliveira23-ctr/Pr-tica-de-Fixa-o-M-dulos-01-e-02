import 'package:flutter/material.dart';

import '../game.dart';
import 'tile.dart';

/// Exibe a grade de tentativas do jogo.
///
/// Demonstra a construção da árvore de widgets combinando
/// [Column] (linhas de tentativas, empilhadas verticalmente) com
/// [Row] (as letras de cada tentativa, lado a lado).
class GameBoard extends StatelessWidget {
  const GameBoard({
    required this.guesses,
    required this.wordLength,
    super.key,
  });

  /// Todas as tentativas da partida (vazias ou preenchidas).
  final List<Word> guesses;

  /// Quantidade de letras em cada palavra.
  final int wordLength;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (final word in guesses)
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              for (var i = 0; i < wordLength; i++)
                Tile(
                  word.isEmpty ? '' : word[i].char,
                  word.isEmpty ? HitType.none : word[i].type,
                ),
            ],
          ),
      ],
    );
  }
}
