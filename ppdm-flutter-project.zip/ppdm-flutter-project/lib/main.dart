import 'package:flutter/material.dart';

import 'screens/game_screen.dart';

void main() {
  runApp(const BirdleApp());
}

/// Widget raiz do aplicativo.
///
/// É um [StatelessWidget] porque não guarda nenhum estado próprio:
/// apenas configura o tema e define qual tela inicial será exibida.
class BirdleApp extends StatelessWidget {
  const BirdleApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Birdle - PPDM',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: Colors.teal,
        useMaterial3: true,
      ),
      home: const GameScreen(),
    );
  }
}
