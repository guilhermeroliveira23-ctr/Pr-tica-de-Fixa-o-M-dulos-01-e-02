# Programação para Dispositivos Móveis (PPDM)
## Tópicos 01 e 02 — Dispositivos Móveis & Criação de Interface

---

## 📝 Parte 1: Respostas Conceituais

### 1. Diferença de Arquiteturas: Nativo vs Cross-Platform/Híbrido

O desenvolvimento **Nativo** (Android com Kotlin/Java ou iOS com Swift/Objective-C) usa a linguagem e o SDK oficial de cada plataforma, compilando diretamente para código de máquina daquele sistema. Isso garante o máximo de performance e acesso total às APIs nativas do dispositivo, mas exige manter **dois códigos-fonte separados** (um para Android, outro para iOS), o que aumenta o custo e o tempo de desenvolvimento.

Já o desenvolvimento **Cross-Platform/Híbrido**, como o Flutter, permite escrever **um único código-fonte** (em Dart, no caso do Flutter) que é compilado para rodar em múltiplas plataformas (Android, iOS, Web, Desktop). O Flutter, especificamente, não usa componentes de UI nativos da plataforma — ele desenha cada widget diretamente na tela através de sua própria engine gráfica (Skia/Impeller), o que garante consistência visual entre plataformas e boa performance, embora ainda possa exigir "pontes" (platform channels) para acessar certas funcionalidades nativas específicas.

**Resumo da diferença principal:** Nativo = um código por plataforma, acesso total ao SDK nativo, maior custo de manutenção. Cross-Platform = um código para todas as plataformas, menor custo e maior velocidade de desenvolvimento, com pequenas limitações de acesso a recursos muito específicos do sistema.

### 2. StatelessWidget vs StatefulWidget

No Flutter, **tudo é um Widget** — desde um simples texto até o layout completo da tela. Existem dois tipos principais:

- **StatelessWidget**: é um widget **imutável**. Uma vez construído, suas propriedades não mudam ao longo do tempo. Ele não guarda nenhum estado interno; se algo precisar mudar, o widget inteiro precisa ser reconstruído a partir de um widget pai.
  - *Exemplo de uso*: um ícone, um texto estático, um logo, um botão cujo texto e aparência nunca mudam (ex: `Text("Bem-vindo ao app")`). Neste projeto, o widget `Tile` (`lib/widgets/tile.dart`) é um `StatelessWidget`: ele só exibe a letra e a cor recebidas por parâmetro.

- **StatefulWidget**: é um widget que possui um **estado mutável** (representado por uma classe `State` associada). Ele pode ser reconstruído dinamicamente em resposta a interações do usuário ou mudanças de dados, sem precisar recriar toda a árvore de widgets ao redor.
  - *Exemplo de uso*: um contador que incrementa a cada clique, um formulário com campos de texto, um checkbox que alterna entre marcado/desmarcado. Neste projeto, a tela `GameScreen` (`lib/screens/game_screen.dart`) é um `StatefulWidget`: ela guarda o estado da partida (tentativas feitas, texto digitado) e atualiza a tela a cada nova tentativa.

**Regra prática**: se o widget precisa "lembrar" de algo e mudar visualmente sem intervenção externa, ele é Stateful. Se ele só exibe informações fixas ou recebidas de fora (via construtor), ele é Stateless.

### 3. O que acontece quando chamamos `setState()`?

Quando `setState()` é chamado dentro de um `StatefulWidget`, o Flutter:

1. Executa a função passada como parâmetro, que normalmente atualiza uma ou mais variáveis internas do estado (ex: registrar uma nova tentativa no jogo).
2. **Marca aquele widget como "sujo" (dirty)**, avisando o framework de que ele precisa ser reconstruído.
3. O Flutter chama novamente o método `build()` daquele widget, gerando uma nova árvore de widgets (uma nova descrição da UI).
4. O Flutter compara essa nova árvore com a anterior (algoritmo de *diffing* da árvore de elementos/render objects) e **atualiza somente as partes da tela que realmente mudaram**, sem redesenhar a interface inteira do zero.

Ou seja, `setState()` não altera a tela diretamente — ele avisa o framework que o estado mudou e "agenda" uma reconstrução eficiente da UI para refletir esse novo estado. No projeto, isso é usado em `_submitGuess()` e `_resetGame()`, em `lib/screens/game_screen.dart`.

---

## 💻 Parte 2: Prática Hands-on — Birdle (Wordle simplificado)

Projeto desenvolvido a partir do **Passo 3 da trilha oficial do Flutter** (*Widget fundamentals* — construção do widget `Tile`), expandido com uma tela completa para aplicar interatividade, gerenciamento de estado e organização de código.

### Estrutura do projeto

```
lib/
├── main.dart              # Ponto de entrada do app (StatelessWidget)
├── game.dart               # Lógica do jogo, sem dependência de UI
├── screens/
│   └── game_screen.dart    # Tela principal (StatefulWidget + setState)
└── widgets/
    ├── tile.dart            # Widget StatelessWidget de uma letra
    └── game_board.dart      # Árvore de widgets: Column de Rows de Tiles
```

### Conceitos aplicados

- **Árvore de Widgets**: `Scaffold` (estrutura da tela) → `Column` (empilha o título, o tabuleiro e o campo de texto) → `Row` (organiza as letras de cada tentativa lado a lado) → `Container` (estiliza cada `Tile`).
- **Interatividade e estado**: o `TextField` captura a tentativa do usuário; o botão "Enviar" chama `_submitGuess()`, que valida a palavra e usa `setState()` para atualizar o tabuleiro.
- **Organização de código**: a lógica do jogo (`game.dart`), os widgets reutilizáveis (`widgets/`) e a tela (`screens/`) ficam em arquivos separados, em vez de tudo em `main.dart`.
- **Prevenção de overflow**: o conteúdo da tela é envolvido por `SingleChildScrollView`, permitindo rolagem em telas menores em vez de estourar o layout.

### Como executar

```bash
flutter pub get
flutter run
```

> **Nota sobre as palavras do jogo**: por brevidade, a lista de palavras válidas em `lib/game.dart` contém poucas palavras de exemplo (conforme o tutorial oficial). Para testar o jogo, use uma das palavras da lista `legalWords` (ex: `aback`, `abase`, `abate`, `abbey`, `abbot`).

### Checklist de entrega

- [x] Tutorial oficial (Passo 3 — Widget fundamentals): [Flutter Getting Started](https://docs.flutter.dev/learn/pathway/tutorial)
- [x] Árvore de widgets construída com `Scaffold`, `Row`, `Column` e `Container`
- [x] Interatividade e alteração de estado implementadas (`StatefulWidget` + `setState()`)
- [x] Código organizado em componentes separados (widgets próprios em arquivos distintos)
- [x] App sem overflow (uso de `SingleChildScrollView` e `Expanded`)

**Link do repositório GitHub:** _adicionar aqui após o push_

---

## ✅ Critério de Aceite
Código executando sem erros e layout sem estouros de tela (overflow).
